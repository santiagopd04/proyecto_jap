# JaP_Santiago_Pereira
 Repositorio creado para el proyecto de e-comerce de JaP.
