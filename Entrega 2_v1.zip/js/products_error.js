
//Dfino array vacio inicial, el cual voy a hacerle el inner
var listaProductos = [];
var arrayProductos = []
var parametro = undefined;
var min = undefined;
var max = undefined;
let htmlContentToAppend = "";


//Defino una funcion que ejecuta el fetch, y actualiza la lista y asi hacer solo un fetch
//Tengo que llamar la funcion despues de hacer filtros o ordenar el array lista, para que se muestre el resultado
function obtenerProductos () {
    fetch(PRODUCTS_URL)
        .then(data => data.json())
        .then(products => {
            for(let i = 0; i < products.length; i++){
                let productInfo = products[i];
                arrayProductos.push(productInfo);
        }})
        
    }

console.log(arrayProductos)
//creo un array que contiene las condiciones de cada escenario de filtrado/ordenado
var definicionesFiltrado = [
    {nombre: 'precioDes', funcion: listaProductos.sort((a, b) => parseInt(b.cost) - parseInt(a.cost))},
    {nombre: 'precioAsc', funcion: listaProductos.sort((a, b) => parseInt(a.cost) - parseInt(b.cost))},
    {nombre: 'vendidosDes', funcion: listaProductos.sort((a, b) => parseInt(b.soldCount) - parseInt(a.soldCount))},
]
    
//defino funcion que agrega el array al HTML
function mostrarProductos () {
    for(let i = 0; i < arrayProductos.length; i++){
    let producto = arrayProductos[i];

         if (((min == undefined) || (min != undefined && parseInt(producto.cost) >= min)) &&
        ((max == undefined) || (max != undefined && parseInt(product.productCount) <= max))){
            htmlContentToAppend += `
    <a href="product-info.html" class="list-group-item list-group-item-action">
    <div class="row">
        <div class="col-3">
            <img src="` + array[i].imgSrc + `" alt="`+ array[i].description +   `" class="img-thumbnail">
        </div>
        <div class="col">
            <div class="d-flex w-100 justify-content-between">
                <h4 class="mb-1">`+ array[i].name +`</h4>
                <small class="text-muted">` + array[i].currency +` `+ array[i].cost + `</small>
                
            </div>
            <p class="mb-1">` + array[i].description + `</p>
            <small class="text-muted">Vendidos:` + array[i].soldCount + `</small>
        </div>
    </div>
</a>`
}
    document.getElementById("products-list").innerHTML = htmlContentToAppend;
}}

console.log(htmlContentToAppend);

//defino funcion que ordena el array
function ordenarProductos (array, parametroactual) {
    parametro = definicionesFiltrado[parametroactual];
    if(parametroactual != undefined){
        arrayProductos = array;
    }
    arrayProductos = mostrarProductos(parametro, arrayProductos);
}
    

//ordena y llama a la funcion mostrarProducto para que muestre en el html
function mostrar(array, parametroactual){
    parametro = parametroactual;
    if(array != undefined){
    arrayProductos = array;
    }
    arrayProductos = ordenarProductos(arrayProductos, parametro);
    mostrarProductos()
}

//agrego un event listener para definir las acciones de los botones
document.addEventListener("DOMContentLoaded", function(e){
    obtenerProductos()
    break
    mostrar(arrayProductos, [0]);
    console.log(arrayProductos)
        })

 /*   document.getElementById("precioAsc").addEventListener("click", function(){
        ordenarProductos(arrayProductos, [1]);
    });

    document.getElementById("sortDesc").addEventListener("click", function(){
        sortAndShowCategories(ORDER_DESC_BY_NAME);
    });

    document.getElementById("sortByCount").addEventListener("click", function(){
        sortAndShowCategories(ORDER_BY_PROD_COUNT);
    });

    document.getElementById("clearRangeFilter").addEventListener("click", function(){
        document.getElementById("rangeFilterCountMin").value = "";
        document.getElementById("rangeFilterCountMax").value = "";

        minCount = undefined;
        maxCount = undefined;

        showCategoriesList();
    });

    document.getElementById("rangeFilterCount").addEventListener("click", function(){
        //Obtengo el mínimo y máximo de los intervalos para filtrar por cantidad
        //de productos por categoría.
        minCount = document.getElementById("rangeFilterCountMin").value;
        maxCount = document.getElementById("rangeFilterCountMax").value;

        if ((minCount != undefined) && (minCount != "") && (parseInt(minCount)) >= 0){
            minCount = parseInt(minCount);
        }
        else{
            minCount = undefined;
        }

        if ((maxCount != undefined) && (maxCount != "") && (parseInt(maxCount)) >= 0){
            maxCount = parseInt(maxCount);
        }
        else{
            maxCount = undefined;
        }

        showCategoriesList();
    });
*/